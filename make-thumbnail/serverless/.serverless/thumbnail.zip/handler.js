'use strict';
const Jimp = require('jimp');

module.exports.hello = async () => {
  const myimage = await Jimp.read(
    'https://images.unsplash.com/photo-1549740425-5e9ed4d8cd34?ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MXwzOTU0NTB8fGVufDB8fHx8&ixlib=rb-1.2.1&w=1000&q=80',
  );
  const bufferData = await myimage
    .cover(250, 250)
    .quality(60)
    .getBufferAsync('image/' + 'png');

  return bufferData;
};
